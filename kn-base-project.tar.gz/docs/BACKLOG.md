# Бэклог проекта: kn-base

**Репозиторий:** https://github.com/madlyinvolved/kn-base
**Спецификация:** [docs/SPEC.md](docs/SPEC.md)
**Обновлено:** 02.04.2026

---

## Как работать с бэклогом

Статусы задач: `⬜ TODO` → `🔧 IN PROGRESS` → `🔍 REVIEW` → `✅ DONE`

Приоритеты: `🔴 Critical` `🟠 High` `🟡 Medium` `⚪ Low`

Каждая задача ссылается на соответствующий раздел спецификации (Task ID из [SPEC.md](docs/SPEC.md)).

---

## Milestone 1: Инициализация проекта

| Статус | Task | Приоритет | Описание | Связь с ТЗ | Ветка |
|--------|------|-----------|----------|------------|-------|
| ⬜ | T-001 | 🔴 | **Инициализация проекта** — `npm create vite@latest`, структура папок, `.gitignore`, `README.md` | SPEC §6, §7 | `feat/init` |
| ⬜ | T-002 | 🟠 | **Линтинг и форматирование** — ESLint flat config, Prettier, `.editorconfig`, husky + lint-staged | SPEC §6 | `feat/lint-setup` |
| ⬜ | T-003 | 🟠 | **CI/CD** — GitHub Actions workflow: lint → test → build. Vercel integration для preview deploys | SPEC §6, M8 | `feat/ci` |

**Definition of Done M1:** Проект собирается, линтер проходит, CI зелёный, пустая страница на Vercel preview.

---

## Milestone 2: Ядро приложения

| Статус | Task | Приоритет | Описание | Связь с ТЗ | Ветка |
|--------|------|-----------|----------|------------|-------|
| ⬜ | T-004 | 🔴 | **Модуль данных** — `src/data/knowledge-base.js` с экспортом `CATEGORIES` и `ARTICLES` | SPEC §4, §7 | `feat/data-module` |
| ⬜ | T-005 | 🔴 | **Layout** — `Layout.jsx`: sticky header с backdrop-blur, footer, контейнер main (max-width 880px) | SPEC FR-06, NFR-01 | `feat/layout` |
| ⬜ | T-006 | 🔴 | **Навигация** — состояния view/category/article, `Breadcrumb.jsx`, scroll-to-top при переходах | SPEC FR-06 | `feat/navigation` |
| ⬜ | T-007 | 🔴 | **Тема** — `global.css` с CSS-переменными, подключение Fraunces + DM Sans, анимации, скроллбары | SPEC NFR-01 | `feat/theme` |

**Definition of Done M2:** Работает навигация между пустыми страницами, хедер и footer на месте, тема применяется.

---

## Milestone 3: Страницы контента

| Статус | Task | Приоритет | Описание | Связь с ТЗ | Ветка |
|--------|------|-----------|----------|------------|-------|
| ⬜ | T-008 | 🔴 | **Главная** — Hero, SearchBar, CategoryGrid со staggered fadeUp-анимацией | SPEC FR-01 | `feat/home` |
| ⬜ | T-009 | 🔴 | **Поиск** — `useSearch` hook, `SearchResults.jsx`, стейт «не найдено» | SPEC FR-04 | `feat/search` |
| ⬜ | T-010 | 🟠 | **Страница категории** — `ArticleList.jsx` с нумерованными карточками | SPEC FR-02 | `feat/category-page` |
| ⬜ | T-011 | 🟠 | **Страница статьи** — `ArticleView.jsx`, `renderContent.js` (парсер `[[id\|text]]`), блок «Ещё в разделе» | SPEC FR-03 | `feat/article-page` |

**Definition of Done M3:** Весь контент отображается, поиск работает, навигация между статьями через ссылки и breadcrumbs.

---

## Milestone 4: AI-ассистент

| Статус | Task | Приоритет | Описание | Связь с ТЗ | Ветка |
|--------|------|-----------|----------|------------|-------|
| ⬜ | T-012 | 🟠 | **FAB-кнопка** — `ChatFab.jsx`: круглая кнопка, пульсация, toggle | SPEC FR-05 | `feat/chat-fab` |
| ⬜ | T-013 | 🟠 | **Окно чата** — `ChatWidget.jsx`: контейнер, хедер, сворачивание, анимация slideUp | SPEC FR-05 | `feat/chat-window` |
| ⬜ | T-014 | 🟠 | **Anthropic API** — `useChat` hook: формирование контекста, отправка, обработка ошибок | SPEC FR-05 | `feat/chat-api` |
| ⬜ | T-015 | 🟡 | **UX чата** — быстрые вопросы, typing-индикатор, ввод/смена API-ключа, автоскролл | SPEC FR-05 | `feat/chat-ux` |

**Definition of Done M4:** Чат открывается поверх страницы, принимает API-ключ, отвечает по базе знаний, сворачивается без потери истории.

---

## Milestone 5: Контент и данные

| Статус | Task | Приоритет | Описание | Связь с ТЗ | Ветка |
|--------|------|-----------|----------|------------|-------|
| ⬜ | T-016 | 🔴 | **Наполнение базы** — Перенести все 14 статей из ТЗ, вычитать тексты | SPEC §4.2 | `content/articles` |
| ⬜ | T-017 | 🟡 | **Перекрёстные ссылки** — Добавить `[[id\|text]]` ссылки между связанными статьями | SPEC FR-03 | `content/cross-links` |
| ⬜ | T-018 | 🟡 | **Инструкция редактора** — `docs/CONTENT-GUIDE.md`: формат данных, примеры, процесс | SPEC §8 | `docs/content-guide` |

**Definition of Done M5:** Весь контент на месте, ссылки работают, есть инструкция для будущих редакторов.

---

## Milestone 6: Адаптивность и полировка

| Статус | Task | Приоритет | Описание | Связь с ТЗ | Ветка |
|--------|------|-----------|----------|------------|-------|
| ⬜ | T-019 | 🟠 | **Мобильная адаптация** — media queries, чат на полную ширину (< 480px), touch-friendly | SPEC NFR-03 | `feat/responsive` |
| ⬜ | T-020 | 🟡 | **Доступность** — семантический HTML, aria-labels, focus ring, skip-to-content, контраст | SPEC NFR-01 | `feat/a11y` |
| ⬜ | T-021 | ⚪ | **Полировка анимаций** — тюнинг таймингов, `prefers-reduced-motion`, проверка на слабых устройствах | SPEC NFR-01 | `feat/animations` |

**Definition of Done M6:** Портал корректно работает на экранах от 320px, проходит базовые a11y-проверки.

---

## Milestone 7: Тестирование

| Статус | Task | Приоритет | Описание | Связь с ТЗ | Ветка |
|--------|------|-----------|----------|------------|-------|
| ⬜ | T-022 | 🟠 | **Unit-тесты** — Vitest: поиск, фильтрация, renderContent, data integrity | SPEC §9 | `test/unit` |
| ⬜ | T-023 | 🟠 | **Компонентные тесты** — RTL: рендер категорий, навигация, breadcrumbs, статьи | SPEC §9 | `test/components` |
| ⬜ | T-024 | 🟡 | **E2E-тесты** — Playwright: сценарий главная→категория→статья→чат, поиск, мобильный viewport | SPEC §9 | `test/e2e` |
| ⬜ | T-025 | 🟡 | **Кросс-браузерное тестирование** — Chrome, Firefox, Safari, iOS Safari, Chrome Android | SPEC NFR-03 | `test/cross-browser` |
| ⬜ | T-026 | 🟠 | **Ревью контента** — Вычитка статей с HR, проверка актуальности контактов и процессов | SPEC §4 | — |

**Definition of Done M7:** Все тесты зелёные, контент вычитан, кросс-браузерные баги зафиксированы.

---

## Milestone 8: Деплой и запуск

| Статус | Task | Приоритет | Описание | Связь с ТЗ | Ветка |
|--------|------|-----------|----------|------------|-------|
| ⬜ | T-027 | 🟠 | **Деплой Vercel** — Подключение репо, build settings, environment variables, preview deploys | SPEC §8 | `feat/deploy` |
| ⬜ | T-028 | 🟡 | **Кастомный домен** — Покупка/привязка домена, SSL, DNS | SPEC §8 | — |
| ⬜ | T-029 | 🟡 | **API-прокси** — Vercel serverless function `/api/chat`, переменная `ANTHROPIC_API_KEY` | SPEC §8 | `feat/api-proxy` |

**Definition of Done M8:** Портал доступен по URL, автодеплой при push в main, API-ключ скрыт.

---

## Порядок выполнения (рекомендуемый)

```
M1 (Инициализация)
 └── M2 (Ядро)
      ├── M3 (Страницы) ← параллельно с M5 (Контент)
      └── M4 (Чат)
           └── M6 (Адаптивность)
                └── M7 (Тестирование)
                     └── M8 (Деплой)
```

M3 и M5 можно вести параллельно. M4 зависит от M2. M7 начинается после M6.
